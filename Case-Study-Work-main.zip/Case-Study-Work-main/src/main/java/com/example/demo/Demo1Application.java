package com.example.demo;

import java.util.Optional;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class Demo1Application {
	public static void main(String[] args) {
		MainController mainController = new MainController();
		SpringApplication.run(Demo1Application.class, args);
	}

}
